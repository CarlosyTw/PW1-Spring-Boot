package br.edu.ifpb.apisinan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSinanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSinanApplication.class, args);
	}

}
